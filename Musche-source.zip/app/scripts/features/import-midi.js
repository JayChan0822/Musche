import { computed, reactive } from 'vue';

const instrumentLibrary = {
  Brass: [
    'Horn', 'French Horn', 'Hn', 'Trumpet', 'Tpt', 'Cornet', 'Trombone', 'Tbn',
    'Bass Trombone', 'B.Tbn', 'Tuba', 'Tba', 'Euphonium', 'Brass',
  ],
  Woodwinds: [
    'Flute', 'Fl', 'Piccolo', 'Picc', 'Oboe', 'Ob', 'English Horn', 'Cor Anglais', 'E.H',
    'Clarinet', 'Cl', 'Bass Clarinet', 'B.Cl', 'Bassoon', 'Bsn', 'Contrabassoon', 'C.Bsn',
    'Saxophone', 'Sax', 'Recorder', 'Woodwinds',
  ],
  Strings: [
    'Violin', 'Vln', 'Viola', 'Vla', 'Cello', 'Violoncello', 'Vc',
    'Double Bass', 'Contrabass', 'Db', 'Cb', 'Bass', 'Strings', 'Str',
  ],
  Percussion: [
    'Timpani', 'Timp', 'Snare', 'SD', 'Bass Drum', 'BD', 'Cymbals', 'Cym', 'Piatti',
    'Triangle', 'Tri', 'Tambourine', 'Tamb', 'Glockenspiel', 'Glock', 'Xylophone', 'Xyl',
    'Vibraphone', 'Vib', 'Marimba', 'Mar', 'Tubular Bells', 'Chimes', 'Drum', 'Percussion', 'Perc',
  ],
  Keys: [
    'Piano', 'Pno', 'Celesta', 'Cel', 'Harpsichord', 'Organ', 'Accordion',
  ],
  Plucks: [
    'Harp', 'Hp', 'Guitar', 'Gtr', 'Mandolin', 'Lute',
  ],
  Vocal: [
    'Soprano', 'Alto', 'Tenor', 'Baritone', 'Bass Voice', 'Choir', 'Voice', 'Vocal',
  ],
};

export function registerImportMidiFeature(context) {
  const { refs, state, utils, actions } = context;
  const {
    settings,
    managingProject,
    showMidiImportModal,
    midiImportData,
    midiBpm,
    midiTempoMap,
    midiTimeSigs,
    midiViewMode,
    midiTimeSig,
    activeImportMenu,
    importMenuPos,
    importSearchQuery,
  } = refs;
  const {
    buildTempoMap,
    buildTimeSigMap,
    extractNotesFromJZZTrack,
    calculateBarQuantizedDuration,
    filterDurationOutlierNotes = (notes) => notes,
    normalizeForMatch,
    generateUniqueId,
    generateRandomHexColor,
    formatSecs,
  } = utils;
  const {
    openAlertModal,
    pushHistory,
    sortedInstruments,
    nextTick,
    getElementById = (id) => document.getElementById(id),
    loadMidiSmf,
  } = actions;

  const midiGroupExpanded = reactive(new Set());

  const toggleMidiGroupExpand = (groupName) => {
    if (midiGroupExpanded.has(groupName)) {
      midiGroupExpanded.delete(groupName);
    } else {
      midiGroupExpanded.add(groupName);
    }
  };

  const sortedLibrary = (() => {
    const list = [];
    Object.entries(instrumentLibrary).forEach(([group, names]) => {
      names.forEach((name) => {
        list.push({ name, group });
      });
    });
    return list.sort((a, b) => b.name.length - a.name.length);
  })();

  const findGroupSmart = (trackName) => {
    const cleanName = normalizeForMatch(trackName);

    for (const item of sortedLibrary) {
      const libName = normalizeForMatch(item.name);
      const escapedLibName = libName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\b${escapedLibName}\\b`, 'i');

      if (regex.test(cleanName)) return item.group;
      if (libName.length < 3 && cleanName === libName) return item.group;
    }

    if (cleanName.includes('string') || cleanName.includes('vln') || cleanName.includes('vla') || cleanName.includes('cello')) return 'Strings';
    if (cleanName.includes('brass') || cleanName.includes('horn') || cleanName.includes('tpt')) return 'Brass';
    if (cleanName.includes('wood') || cleanName.includes('flute') || cleanName.includes('oboe')) return 'Woodwinds';
    if (cleanName.includes('perc') || cleanName.includes('drum')) return 'Percussion';

    return '';
  };

  const findGroupFromLibrary = (cleanName) => {
    const target = cleanName.toLowerCase();

    for (const [groupName, instruments] of Object.entries(instrumentLibrary)) {
      const match = instruments.find((instrument) => {
        const libInst = instrument.toLowerCase();
        return libInst === target || target.includes(libInst);
      });

      if (match) return groupName;
    }

    return '';
  };

  const availableInstrumentGroups = computed(() => {
    const groups = new Set(['Unassigned']);

    settings.instruments.forEach((item) => {
      if (item.group) groups.add(item.group);
    });

    ['Strings', 'Brass', 'Woodwinds', 'Percussion', 'Keys', 'Plucks', 'Vocal', 'Synth'].forEach((group) => {
      groups.add(group);
    });

    if (showMidiImportModal.value) {
      midiImportData.value.forEach((track) => {
        if (track.group && track.group.trim()) {
          groups.add(track.group.trim());
        }
      });
    }

    return Array.from(groups).sort();
  });

  const midiGroupData = computed(() => {
    const groupsMap = {};

    midiImportData.value.forEach((track) => {
      const groupName = track.group && track.group.trim() !== '' ? track.group : 'Unassigned';
      if (!groupsMap[groupName]) {
        groupsMap[groupName] = { name: groupName, items: [] };
      }
      groupsMap[groupName].items.push(track);
    });

    return Object.values(groupsMap)
      .map((group) => {
        const selectedItems = group.items.filter((item) => item.selected);
        const hasSelection = selectedItems.length > 0;

        let finalDuration = 0;
        let totalNotes = 0;
        let maxBars = 0;

        if (hasSelection && midiTempoMap.value && midiTimeSigs.value) {
          const allGroupNotes = [];
          selectedItems.forEach((item) => {
            totalNotes += item.noteCount;
            if (item.durationNotes || item.notes) allGroupNotes.push(...(item.durationNotes || item.notes));
          });

          if (allGroupNotes.length > 0) {
            allGroupNotes.sort((a, b) => a.ticks - b.ticks);
            const analysis = calculateBarQuantizedDuration(allGroupNotes, midiTempoMap.value, midiTimeSigs.value);
            finalDuration = analysis.seconds;
            maxBars = analysis.bars;
          }
        } else {
          selectedItems.forEach((item) => {
            finalDuration = Math.max(finalDuration, item.quantizedDuration);
            totalNotes += item.noteCount;
            maxBars = Math.max(maxBars, item.bars || 0);
          });
        }

        const genericInstrument = settings.instruments.find(
          (item) =>
            item.name.toLowerCase() === group.name.toLowerCase() ||
            (item.group === group.name && item.name.toLowerCase().includes('section')),
        );

        return {
          id: `GRP_${group.name}`,
          name: group.name,
          originalName: group.name,
          instrumentId: genericInstrument ? genericInstrument.id : '',
          createNew: !genericInstrument,
          quantizedDuration: finalDuration,
          bars: maxBars,
          noteCount: totalNotes,
          group: group.name,
          selected: hasSelection,
          items: group.items,
          isGroup: true,
          description: `${selectedItems.length} / ${group.items.length} tracks`,
        };
      })
      .sort((a, b) => {
        if (a.name === 'Unassigned') return 1;
        if (b.name === 'Unassigned') return -1;
        return a.name.localeCompare(b.name, 'zh-CN');
      });
  });

  const currentMidiDisplayList = computed(() =>
    midiViewMode.value === 'groups' ? midiGroupData.value : midiImportData.value,
  );

  const filteredImportOptions = computed(() => {
    const search = importSearchQuery.value.toLowerCase();

    if (activeImportMenu.type === 'inst') {
      return sortedInstruments.value.filter((item) =>
        item.name.toLowerCase().includes(search) ||
        (item.group && item.group.toLowerCase().includes(search)),
      );
    }

    if (activeImportMenu.type === 'group') {
      return availableInstrumentGroups.value.filter((group) =>
        group.toLowerCase().includes(search),
      );
    }

    return [];
  });

  function closeImportMenu() {
    activeImportMenu.rowId = null;
    activeImportMenu.type = null;
  }

  function openImportMenu(event, rowId, type) {
    if (activeImportMenu.rowId === rowId && activeImportMenu.type === type) {
      closeImportMenu();
      return;
    }

    const rect = event.currentTarget.getBoundingClientRect();
    importMenuPos.top = rect.bottom + 5;
    importMenuPos.left = rect.left;
    importMenuPos.width = rect.width;

    activeImportMenu.rowId = rowId;
    activeImportMenu.type = type;
    importSearchQuery.value = '';

    nextTick(() => {
      const input = getElementById('midi-import-search');
      if (input) input.focus();
    });
  }

  function selectImportInst(track, inst) {
    track.instrumentId = inst.id;

    if (inst.group && midiViewMode.value !== 'groups') {
      track.group = inst.group;
    }

    track.createNew = false;
    closeImportMenu();
  }

  function selectImportNewInst(track) {
    track.instrumentId = '';
    track.createNew = true;
    closeImportMenu();
  }

  function selectImportGroup(track, groupName) {
    track.group = groupName;
    closeImportMenu();
  }

  function triggerMidiImportForProject() {
    const input = document.getElementById('midi-import-input');
    if (input) {
      input.value = '';
      input.click();
    }
  }

  function triggerMidiImport() {
    const input = document.getElementById('midi-import-input');
    if (input) {
      input.value = '';
      input.click();
    }
  }

  function handleMidiFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (!managingProject.value) {
      if (settings.projects.length > 0) {
        managingProject.value = settings.projects[0];
        if (!managingProject.value.midiData) {
          managingProject.value.midiData = {};
        }
      } else {
        openAlertModal('无法导入', '请先至少创建一个项目 (Project) 后再导入 MIDI。');
        event.target.value = '';
        return;
      }
    }

    processMidiFile(file);
    event.target.value = '';
  }

  function processMidiFile(file) {
    const matchName = (name) => normalizeForMatch(String(name || '')
      .normalize('NFKC')
      .replace(/[()[\]{}]/g, ' ')
      .replace(/([\p{Script=Han}])([a-z])/gi, '$1 $2')
      .replace(/([a-z])([\p{Script=Han}])/gi, '$1 $2'))
      .replace(/[^\p{L}\p{N}#]+/gu, ' ')
      .replace(/\s+(?:r|l|rh|lh|right|left|i{1,3}|iv|v|vi)\s*$/i, '')
      .trim();
    const nameAliases = (name) => [...new Set([
      name,
      // Bilingual library labels and track labels can have different translations.
      ...(name.match(/[a-z#]+(?:\s+[a-z#]+)*/g) || []),
      ...(name.match(/\p{Script=Han}+/gu) || []),
    ])].filter(Boolean);
    const findInstrument = (name) => {
      const target = matchName(name);
      if (!target) return null;
      const aliases = nameAliases(target);
      const candidates = settings.instruments.map((instrument) => ({
        instrument,
        name: matchName(instrument.name),
      })).filter((item) => item.name);
      const exact = candidates.filter((item) => item.name === target);
      if (exact.length) return exact.length === 1 ? exact[0].instrument : null;

      const scored = candidates.map((item) => {
        let score = 0;
        for (const left of aliases) {
          for (const right of nameAliases(item.name)) {
            if (left === right) score = Math.max(score, 1000 + left.length);
            else {
              const shorter = left.length < right.length ? left : right;
              const longer = left.length < right.length ? right : left;
              if (shorter.length > 2 && ` ${longer} `.includes(` ${shorter} `)) {
                score = Math.max(score, shorter.length);
              }
            }
          }
        }
        return { ...item, score };
      });
      const bestScore = Math.max(0, ...scored.map((item) => item.score));
      const best = scored.filter((item) => item.score === bestScore);
      return bestScore > 0 && best.length === 1 ? best[0].instrument : null;
    };

    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = async (loadEvent) => {
      try {
        const midiSmf = await loadMidiSmf();
        if (typeof midiSmf !== 'function') {
          openAlertModal('库丢失', 'JZZ MIDI 库未加载，请检查网络。');
          return;
        }

        const data = loadEvent.target.result;
        const smf = midiSmf(data);

        const tempoMap = buildTempoMap(smf);
        const timeSigs = buildTimeSigMap(smf);
        midiTempoMap.value = tempoMap;
        midiTimeSigs.value = timeSigs;

        const firstTempo = tempoMap.events.find((event) => event.bpm) || { bpm: 120, mpb: 500000 };
        midiBpm.value = Math.round(60000000 / firstTempo.mpb);
        midiTimeSig.value = timeSigs[0].timeSignature;

        const mergedMap = {};

        smf.forEach((track, index) => {
          let rawName = '';
          track.forEach((event) => {
            if (event.ff === 0x03) rawName = event.dd;
          });
          if (!rawName) rawName = `Track ${index + 1}`;

          let displayName = rawName.replace(/\0/g, '').trim();
          displayName = displayName
            .replace(/[\s\-_]?Flat/gi, 'b')
            .replace(/[\s\-_]?Sharp/gi, '#')
            .replace(/♭/g, 'b')
            .replace(/♯/g, '#');

          const trackNotes = extractNotesFromJZZTrack(track);
          if (trackNotes.length === 0 && !displayName) return;

          if (!mergedMap[displayName]) {
            mergedMap[displayName] = {
              name: displayName,
              notes: [],
              firstTrackIndex: index,
              trackCount: 0,
            };
          }

          mergedMap[displayName].notes.push(...trackNotes);
          mergedMap[displayName].trackCount++;
        });

        const processedTracks = [];
        let uniqueIdCounter = 0;

        for (const name in mergedMap) {
          const groupData = mergedMap[name];
          const notes = groupData.notes;
          const durationNotes = filterDurationOutlierNotes(notes, tempoMap.ppq);
          let matchedInstrumentId = '';
          let matchedGroup = findGroupSmart(groupData.name);

          const found = findInstrument(groupData.name);

          if (found) {
            matchedInstrumentId = found.id;
            if (found.group) matchedGroup = found.group;
          }

          let analysis = { seconds: 0, rawSeconds: 0, bars: 0 };
          if (durationNotes.length > 0) {
            analysis = calculateBarQuantizedDuration(durationNotes, tempoMap, timeSigs);
          }

          const isTechnicalEmpty = notes.length === 0;
          const cleanNameForCreation = groupData.name.replace(/\s+\d+$/, '').trim();

          processedTracks.push({
            id: uniqueIdCounter++,
            name: groupData.name,
            originalName: groupData.name,
            suggestedInstName: cleanNameForCreation,
            instrumentId: matchedInstrumentId,
            createNew: !matchedInstrumentId && !isTechnicalEmpty,
            notes,
            durationNotes,
            rawDuration: analysis.rawSeconds,
            quantizedDuration: analysis.seconds,
            bars: analysis.bars,
            noteCount: notes.length,
            group: matchedGroup || 'Unassigned',
            selected: !isTechnicalEmpty,
            description: groupData.trackCount > 1 ? `Merged ${groupData.trackCount} duplicate tracks` : '',
            _sortIndex: groupData.firstTrackIndex,
          });
        }

        processedTracks.sort((a, b) => a._sortIndex - b._sortIndex);
        if (processedTracks.length === 0) {
          openAlertModal('无数据', '未解析到任何有效轨道。');
          return;
        }

        midiImportData.value = processedTracks;
        showMidiImportModal.value = true;
      } catch (error) {
        console.error('JZZ Parse Error:', error);
        openAlertModal('解析错误', `文件解析失败: ${error.message}`);
      }
    };
  }

  function onImportInstChange(track) {
    track.createNew = false;
    if (track.instrumentId) {
      const instrument = settings.instruments.find((item) => item.id === track.instrumentId);
      if (instrument) track.group = instrument.group || 'Unassigned';
    }
  }

  function getSmartName(row) {
    if (!row) return 'New Instrument';
    if (row.isGroup) return row.name;
    if (row.name !== row.originalName) return row.name;
    return row.suggestedInstName || row.name;
  }

  function confirmMidiImport() {
    if (!managingProject.value) {
      openAlertModal('错误', '未找到关联的项目，无法保存数据。');
      return;
    }

    if (!managingProject.value.midiData) managingProject.value.midiData = {};

    let count = 0;
    const sourceList = midiViewMode.value === 'groups' ? midiGroupData.value : midiImportData.value;
    const tempMap = {};

    sourceList.forEach((row) => {
      if (!row.selected) return;

      let targetInstrumentId = row.instrumentId;

      if (!targetInstrumentId && row.createNew) {
        const rawFinalName = row.name !== row.originalName ? row.name : row.suggestedInstName || row.name;
        const finalName = rawFinalName.trim();
        const normalizedFinalName = normalizeForMatch(finalName);
        const existing = settings.instruments.find((item) => normalizeForMatch(item.name) === normalizedFinalName);

        if (existing) {
          targetInstrumentId = existing.id;
        } else {
          const newId = generateUniqueId('I');
          settings.instruments.push({
            id: newId,
            name: finalName,
            group: row.group || 'Unassigned',
            color: generateRandomHexColor(),
          });
          targetInstrumentId = newId;
        }
      }

      if (!targetInstrumentId) return;

      if (!tempMap[targetInstrumentId]) tempMap[targetInstrumentId] = [];
      tempMap[targetInstrumentId].push({
        name: row.name,
        duration: formatSecs(row.quantizedDuration),
        _sortIndex: row._sortIndex || 0,
      });
      count++;
    });

    if (count === 0) {
      openAlertModal('提示', '请至少选择一条可导入的 MIDI 轨道。');
      return;
    }

    Object.entries(tempMap).forEach(([instId, items]) => {
      items.sort((a, b) => a._sortIndex - b._sortIndex);
      managingProject.value.midiData[instId] = items.map((item) => ({
        name: item.name,
        duration: item.duration,
        order: item._sortIndex,
      }));
    });

    pushHistory();
    showMidiImportModal.value = false;
    openAlertModal('导入成功', `已导入 ${count} 条轨道数据 (支持分部)。`);
  }

  return {
    availableInstrumentGroups,
    midiGroupExpanded,
    midiGroupData,
    currentMidiDisplayList,
    filteredImportOptions,
    toggleMidiGroupExpand,
    findGroupSmart,
    findGroupFromLibrary,
    openImportMenu,
    closeImportMenu,
    selectImportInst,
    selectImportNewInst,
    selectImportGroup,
    triggerMidiImportForProject,
    triggerMidiImport,
    handleMidiFile,
    processMidiFile,
    onImportInstChange,
    getSmartName,
    confirmMidiImport,
  };
}
